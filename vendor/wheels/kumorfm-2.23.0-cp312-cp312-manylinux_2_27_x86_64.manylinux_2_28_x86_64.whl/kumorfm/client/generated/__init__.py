"""Generated client metadata."""

