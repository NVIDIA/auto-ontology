"""Addressing a model served by a managed platform rather than by URL.

:class:`~nvidia_sdfm.core.transport.Transport` speaks HTTP to a NIM at a base
URL. A Databricks Model Serving endpoint is addressed by *name* through a
workspace client, so there is no URL, no API key, and no readiness route.

This carries that target instead. It exposes the same ``url``,
``health_ready`` and ``predict`` members a :class:`Transport` does, but every
one of them refuses: each raises an :class:`SdfmError` naming the endpoint and
the reason it does not apply. An adapter reaching for one is a bug, and it
surfaces as that error rather than as a plausible-looking value or a request
to nowhere.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nvidia_sdfm.errors import SdfmError


@dataclass(frozen=True)
class ServingTarget:
    """A model served by name on a managed platform.

    Attributes:
        endpoint: The serving endpoint name.
        workspace_client: An injected platform client, or ``None`` to build one
            from ambient configuration. Kept out of ``repr``: a real
            ``WorkspaceClient`` renders its workspace host, and an injected one
            renders whatever it likes, including credentials.

    Frozen, because the endpoint and workspace client are this target's
    identity. Whether it is still usable is not, so ``_closed`` is set through
    ``object.__setattr__``.
    """

    endpoint: str
    workspace_client: Any | None = field(default=None, repr=False)
    _closed: bool = field(default=False, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if not isinstance(self.endpoint, str) or not self.endpoint.strip():
            raise SdfmError(
                'endpoint must be a non-empty serving endpoint name',
                code='INVALID_CONFIGURATION',
            )
        if any(token in self.endpoint for token in ('://', '/', '?', '#', '@')):
            raise SdfmError(
                'endpoint must be a serving endpoint name, not a URL',
                code='INVALID_CONFIGURATION',
            )
        if self.endpoint != self.endpoint.strip():
            raise SdfmError(
                'endpoint name has surrounding whitespace',
                code='INVALID_CONFIGURATION',
            )

    def close(self) -> None:
        """Mark the target closed.

        There is nothing to release -- the workspace client owns its own
        transport -- but a closed client must refuse work here exactly as it
        does over HTTP. Otherwise ``close()`` followed by ``predict()`` fails
        on one transport and silently succeeds on the other.
        """
        object.__setattr__(self, '_closed', True)

    def _require_open(self) -> None:
        """Part of the transport contract ``SDFMClient._predict`` relies on.

        Absent it, the serving path raises ``AttributeError`` from inside the
        client rather than the documented error.
        """
        if self._closed:
            raise SdfmError(
                'this client is closed; construct a new SDFMClient',
                code='INVALID_CONFIGURATION',
            )

    @property
    def url(self) -> str:
        raise SdfmError(
            f'the serving endpoint {self.endpoint!r} has no URL; it is '
            'addressed by name through a workspace client',
            code='INVALID_CONFIGURATION',
        )

    def health_ready(self) -> bool:
        raise SdfmError(
            f'the serving endpoint {self.endpoint!r} exposes no readiness '
            "route; use the platform's own endpoint status instead",
            code='UNSUPPORTED_FEATURE',
        )

    def predict(self, payload: dict[str, Any]) -> dict[str, Any]:
        raise SdfmError(
            f'the model served at {self.endpoint!r} does not support '
            'serving-mode invocation through the generic transport; only '
            'KumoRFM does',
            code='UNSUPPORTED_FEATURE',
        )
